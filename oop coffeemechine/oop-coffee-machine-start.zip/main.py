from menu import Menu
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine
